<?php
	$x = 0;
	if( $x == 0 ){

		$_cfg['sitio']['url'] = "https://www.bpi.com.pe/";
		$_cfg['sitio']['ruta']= $_SERVER['DOCUMENT_ROOT']."/";

	}else if( $x == 1 ){

		$_cfg['sitio']['url'] = "";
		$_cfg['sitio']['ruta']= $_SERVER['DOCUMENT_ROOT']."/";

	}
?>