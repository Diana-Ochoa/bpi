<header>
  <section id="top" class="width100p background_azul1">
    <div id="bpi-wrap">
      <div class="tipo_cambio fontweight500">Tipo de cambio del dólar actual en Perú: <i class="fas fa-arrow-square-up"></i> <span>Compra:</span> 3.321 <i class="fas fa-arrow-square-down"></i> <span>Venta:</span> 3.363</div>
    </div>
  </section>

  <section id="cabecera" class="width100p background_azul2">
    <div id="bpi-wrap">
      <div class="logo"><a href="<?=_base_?>"><span class="logo_bpi">BPI</span></a></div>
      <div class="root fontweight500">
        <div class="navegacion"><span>MENÚ</span> <a data-toggle="modal" data-target="#exampleModalCenter"><span class="menu_root azul2">Menú</span></a></div>
        <div class="btn_ca"><a href="<?=_base_?>acceso-restringido/" class="iniciarsesion">Iniciar sesión</a> <a href="<?=_base_?>" class="suscribase" style="display:none;">Suscríbase</a></div>
      </div>
    </div>
  </section>
</header>

<?php include(_includes_."inc.menu.php"); ?>