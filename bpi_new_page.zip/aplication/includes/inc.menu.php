

<link rel="stylesheet" href="<?=_css_?>bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>


<?php
/** ____________________________________________________________________________________________________________________________________________________________________________________ **/
function isMobileDevice2() {
  return preg_match("/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i", $_SERVER["HTTP_USER_AGENT"]);
}

  if(isMobileDevice2()){
/** ____________________________________________________________________________________________________________________________________________________________________________________ **/
?>

<!-- MENÚ MODAL -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="padding-right:25px; padding-left:25px;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content" style="border:0px solid #0e3d88">
      
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        
        <div id="footer_capa1" class="background_azul2 width100p blanco1" style="padding-top:0px; padding-bottom:30px;">
          <div id="bpi-wrap">

            <div class="bpi_footer">
              <h3 class="colorceleste1">¿Quiénes somos?</h3>
              <ul>
                <li><a href="<?=_base_?>quienes-somos/">Misión</a></li>
                <li><a href="<?=_base_?>quienes-somos/">Visión</a></li>
                <li><a href="<?=_base_?>quienes-somos/">Objetivos</a></li>
                <li><a href="<?=_base_?>quienes-somos/">Nuestros valores</a></li>
              </ul>
            </div>

            <div class="bpi_footer">
              <h3 class="colorceleste1">Nuestros productos</h3>
              <ul>
                <li><a href="<?=_base_?>ahorro-plazo-fijo/">Ahorro plazo fijo</a></li>
                <li><a href="<?=_base_?>credito/">Crédito</a></li>
                <li><a href="<?=_base_?>prestamo/">Préstamo</a></li>
                <li><a href="<?=_base_?>cambio-de-divisa/">Cambio de divisa</a></li>
                <li><a href="<?=_base_?>inversion-inmobiliaria/">Inversión inmobiliaria</a></li>
              </ul>
            </div>

            <div class="bpi_footer">
              <ul>
                <li><a href="<?=_base_?>contactanos/">Contáctanos</a></li>
                <li><a href="<?=_base_?>contactanos/">Ubícanos</a></li>
                <li style="display:none;"><a href="<?=_base_?>assessment/">Assessment</a></li>
                <li style="display:none;"><a href="<?=_base_?>binarial/">Binarial</a></li>
                <li><a href="http://divisa.bpi.com.pe/">Divisa</a></li>
                <li><a href="<?=_base_?>acceso-restringido/">Iniciar sesión</a></li>
                <li></li>
                <li></li>
                <li style="display:none;"><a href="<?=_base_?>transparentes/">Transparentes</a></li>
                <li style="display:none;"><a href="<?=_base_?>seguridad-de-informacion/">Seguridad de información</a></li>
                <li style="display:none;"><a href="<?=_base_?>datos-personales/">Datos personales</a></li>
                <li style="display:none;"><a href="<?=_base_?>canales-de-atencion/">Canales de atención</a></li>
                <li></li>
                <li></li>
                <li style="font-size:12px;">Síguenos:
                  <a href="https://www.facebook.com/bpitodosganan/" target="_blank"><div><i class="fab fa-facebook-f"></i></div></a>
                  <a href="https://instagram.com/bpi_todosganan?igshid=12aq6qsq7rrx8" target="_blank"><div><i class="fab fa-instagram"></i></div></a>
                  <a href="https://www.linkedin.com/company/bpi-banco-peruano-de-inversiones" target="_blank"><div><i class="fab fa-linkedin-in"></i></div></a>
                </li>
              </ul>
            </div>


                
          </div>
          </div>


      </div>

    </div>
  </div>
</div>



<?php
/** ____________________________________________________________________________________________________________________________________________________________________________________ **/
  } else {
/** ____________________________________________________________________________________________________________________________________________________________________________________ **/
?>


<!-- MENÚ MODAL -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true" style="padding-right:25px; padding-left:25px;">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
        
        <div id="footer_capa1" class="background_azul2 width100p blanco1">
          <div id="bpi-wrap" style="padding-left:0px; padding-right:0px;">

            <div class="bpi_footer">
              <div class="logo_footer"><a href="<?=_base_?>"><span class="logo_bpi">BPI</span></a></div>  
              <div class="direccion_footer">
                <span>Oficina principal</span><br/>
                Dirección: Av. Javier Prado 476 Piso 21<br/>
                San Isidro<br/><br/>

                <span>Prevía cita</span><br/>
                Dirección: Av. El Derby 250 Piso 12<br/>
                Santiago de Surco<br/><br/>

                Dirección Av. Paseo de la República 5985<br/>
                Piso 10<br/>
                Miraflores
              </div>
            </div>

            <div class="bpi_footer">
              <h3 class="colorceleste1">¿Quiénes somos?</h3>
              <ul>
                <li><a href="<?=_base_?>quienes-somos/">Misión</a></li>
                <li><a href="<?=_base_?>quienes-somos/">Visión</a></li>
                <li><a href="<?=_base_?>quienes-somos/">Objetivos</a></li>
                <li><a href="<?=_base_?>quienes-somos/">Nuestros valores</a></li>
              </ul>
            </div>

            <div class="bpi_footer">
              <h3 class="colorceleste1">Nuestros productos</h3>
              <ul>
                <li><a href="<?=_base_?>ahorro-plazo-fijo/">Ahorro plazo fijo</a></li>
                <li><a href="<?=_base_?>credito/">Crédito</a></li>
                <li><a href="<?=_base_?>prestamo/">Préstamo</a></li>
                <li><a href="<?=_base_?>cambio-de-divisa/">Cambio de divisa</a></li>
                <li><a href="<?=_base_?>inversion-inmobiliaria/">Inversión inmobiliaría</a></li>
              </ul>
            </div>

            <div class="bpi_footer">
              <ul>
                <li style="display:none;"><a href="<?=_base_?>assessment/">Assessment</a></li>
                <li style="display:none;"><a href="<?=_base_?>binarial/">Binarial</a></li>
                <li><a href="<?=_base_?>contactanos/">Contáctanos</a></li>
                <li><a href="<?=_base_?>ubicanos/">Úbicanos</a></li>
                <li><a href="<?=_base_?>analytics/">Analytics</a></li>
                <li></li>
                <li></li>
                <li style="display:none;"><a href="<?=_base_?>transparentes/">Transparentes</a></li>
                <li style="display:none;"><a href="<?=_base_?>seguridad-de-informacion/">Seguridad de información</a></li>
                <li style="display:none;"><a href="<?=_base_?>datos-personales/">Datos personales</a></li>
                <li style="display:none;"><a href="<?=_base_?>canales-de-atencion/">Canales de atención</a></li>
                <li></li>
                <li></li>
                <li style="font-size:12px;">Síguenos:
                  <a href="https://www.facebook.com/bpitodosganan/" target="_blank"><div><i class="fab fa-facebook-f"></i></div></a>
                  <a href="https://instagram.com/bpi_todosganan?igshid=12aq6qsq7rrx8" target="_blank"><div><i class="fab fa-instagram"></i></div></a>
                  <a href="https://www.linkedin.com/company/bpi-banco-peruano-de-inversiones" target="_blank"><div><i class="fab fa-linkedin-in"></i></div></a>
                </li>
              </ul>
            </div>


                
          </div>
          </div>


      </div>

    </div>
  </div>
</div>

<?php
/** ____________________________________________________________________________________________________________________________________________________________________________________ **/
  }
/** ____________________________________________________________________________________________________________________________________________________________________________________ **/
?>