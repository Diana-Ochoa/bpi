<footer style="position:relative; z-index:9;">
  <div id="footer_capa1" class="background_azul2 width100p blanco1">
    <div id="bpi-wrap">

      <div class="bpi_footer">
        <div class="logo_footer"><a href="<?=_base_?>"><span class="logo_bpi">BPI</span></a></div>  
        <div class="direccion_footer">
          <span>Oficina principal</span><br/>
          Dirección: Av. Javier Prado 476 Piso 21<br/>
          San Isidro<br/><br/>

          <span>Previa cita</span><br/>
          Dirección: Av. El Derby 250 Piso 12<br/>
          Santiago de Surco<br/><br/>

          Dirección Av. Paseo de la República 5985<br/>
          Piso 10<br/>
          Miraflores
        </div>
      </div>

      <div class="bpi_footer">
        <h3 class="colorceleste1">¿Quiénes somos?</h3>
        <ul>
          <li><a href="<?=_base_?>quienes-somos/">Misión</a></li>
          <li><a href="<?=_base_?>quienes-somos/">Visión</a></li>
          <li><a href="<?=_base_?>quienes-somos/">Objetivos</a></li>
          <li><a href="<?=_base_?>quienes-somos/">Nuestros valores</a></li>
        </ul>
      </div>

      <div class="bpi_footer">
        <h3 class="colorceleste1">Nuestros productos</h3>
        <ul>
          <li><a href="<?=_base_?>ahorro-plazo-fijo/">Ahorro Plazo Fijo</a></li>
          <li><a href="<?=_base_?>credito/">Crédito</a></li>
          <li><a href="<?=_base_?>prestamo/">Préstamo</a></li>
          <li><a href="<?=_base_?>cambio-de-divisas/">Cambio de divisas</a></li>
          <li><a href="<?=_base_?>inversion-inmobiliaria/">Inversión Inmobiliaria</a></li>
        </ul>
      </div>

      <div class="bpi_footer">
        <ul>
          <li style="display:none;"><a href="<?=_base_?>assessment/">Assessment</a></li>
          <li style="display:none;"><a href="<?=_base_?>binarial/">Binarial</a></li>
          <li><a href="<?=_base_?>contactanos/">Contáctanos</a></li>
          <li><a href="<?=_base_?>contactanos/">Ubícanos</a></li>
          <li><a href="http://divisa.bpi.com.pe/">Divisa</a></li>
          <li></li>
          <li></li>
          <li style="display:none;"><a href="<?=_base_?>transparentes/">Transparentes</a></li>
          <li style="display:none;"><a href="<?=_base_?>seguridad-de-informacion/">Seguridad de información</a></li>
          <li style="display:none;"><a href="<?=_base_?>datos-personales/">Datos personales</a></li>
          <li style="display:none;"><a href="<?=_base_?>canales-de-atencion/">Canales de atención</a></li>
          <li></li>
          <li></li>
          <li style="font-size:12px;">Síguenos en:
            <a href="https://www.facebook.com/bpitodosganan/" target="_blank"><div><i class="fab fa-facebook-f"></i></div></a>
            <a href="https://instagram.com/bpi_todosganan?igshid=12aq6qsq7rrx8" target="_blank"><div><i class="fab fa-instagram"></i></div></a>
            <a href="https://www.linkedin.com/company/bpi-banco-peruano-de-inversiones" target="_blank"><div><i class="fab fa-linkedin-in"></i></div></a>
          </li>
        </ul>
      </div>


          
    </div>
    </div>

    <div id="footer_capa2" class="background_azul1 width100p blanco1">
      <div id="bpi-wrap">
        <div class="copyright">© Copyright 2020 - Todo los derechos reservados.</div>
        <div class="condicion"><a href="<?=_base_?>terminos-y-condiciones/">Términos y condiciones</a> | <a href="#">Libro de reclamaciones</a></div>
      </div>
    </div>
</footer>

  <!-- AOS ANIMATION -->
  <script src='https://unpkg.com/aos@2.3.0/dist/aos.js'></script>
  <script id="rendered-js">
  AOS.init({
    duration: 800 });
  </script>
  <link rel='stylesheet' href='https://unpkg.com/aos@2.3.0/dist/aos.css'>

</body>
</html>