<?php include_once("inc.core.php"); ?>
<?php include(_includes_."inc.head.php"); ?>
<?php include(_includes_."inc.top.php"); ?>
<?php //include(_includes_."inc.slidercredito.php"); ?>

<section id="cuerpo_bpi">
	<div id="bpi-wrap">
		
		<div style="width:100%; text-align:center; height:450px; vertical-align:middle;" data-aos="fade-down">
			<h1 class="azul1" style="font-size:80px; padding-top:70px; margin:0;">¡Oh, no!</h1>
			<h2 class="gris2">Esta página no existe.</h2>
			<p>Parece que no se encontró nada. ¿Tal vez pueda intentar dando clic al botón?</p>
			<a href="<?=_base_?>" style="border:0px; background-color:#053d8e; color:#FFF; margin-top:20px; padding:10px 20px 10px 20px; text-align:center; border-radius:5px; display:inline-block;">Regresar al inicio</a>
		</div>

	</div>
</section>


<?php include(_includes_."inc.footer.php"); ?>