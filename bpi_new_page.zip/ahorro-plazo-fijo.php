<?php include_once("inc.core.php"); ?>
<?php include(_includes_."inc.head.php"); ?>
<?php include(_includes_."inc.top.php"); ?>
<?php include(_includes_."inc.sliderahorroplazofijo.php"); ?>

<section id="cuerpo_bpi">
	<div id="bpi-wrap">
		
		<div class="ahorro_capas" data-aos="fade-down">
			
<div class="n2-section-smartslider " role="region" aria-label="Slider"><style>div#n2-ss-13{width:1250px;float:left;margin:0px 0px 0px 0px;}.x-rtl div#n2-ss-13{float:right;}div#n2-ss-13 .n2-ss-slider-1{position:relative;height:370px;}div#n2-ss-13 .n2-ss-slider-2{position:relative;height:370px;overflow:hidden;border-style:solid;border-width:0px;border-color:#3e3e3e;border-color:RGBA(62,62,62,1);border-radius:0px;background-clip:padding-box;background-repeat:repeat;background-position:50% 50%;background-size:cover;background-attachment:scroll;background-color:#fff;background-color:RGBA(255,255,255,0.5);z-index:1;}div#n2-ss-13 .n-particles-js-canvas-el{position:absolute;left:0;top:0;width:100%;height:100%;z-index:12;}div#n2-ss-13 .n2-ss-slider-3{position:relative;width:100%;height:100%;overflow:hidden;z-index:20;}div#n2-ss-13 .n2-ss-slider-pane{position:relative;width:100%;height:100%;overflow:hidden;}div#n2-ss-13 .n2-ss-slider-pane-single{position:relative;width:100%;overflow:hidden;}div#n2-ss-13 .n2-ss-slider-pane-single:after{content:"";display:block;clear:both;}div#n2-ss-13 .n2-ss-slider-pipeline{height:100%;width:100000%;float:left;position:relative !important;transform-style:preserve-3d;}[dir="rtl"] div#n2-ss-13 .n2-ss-slider-pipeline{float:right;}.x-msie div#n2-ss-13 .n2-ss-slider-pipeline{perspective:1000px;backface-visibility:visible;transform-origin:50% 50% 0;}div#n2-ss-13 .n2-ss-slide-group{position:absolute;left:0;top:0;width:100%;height:100%;}div#n2-ss-13 .n2-ss-slide{position:relative;width:375px;height:370px;float:left;display:block;border-radius:0px;background-clip:padding-box;background-color:#fff;background-color:RGBA(255,255,255,1);z-index:1;}[dir="rtl"] div#n2-ss-13 .n2-ss-slide{float:right;}div#n2-ss-13 .n2-ss-layers-container{position:relative;width:375px;height:370px;}div#n2-ss-13 .n2-ss-slide{perspective:1000px;}div#n2-ss-13[data-ie] .n2-ss-slide{perspective:none;transform:perspective(1000px);}div#n2-ss-13 .n2-ss-slide-active{z-index:3;display:block;}div#n2-ss-13 .n2-ss-layer{-webkit-backface-visibility:hidden;}div#n2-ss-13 .n2-ss-control-bullet{visibility:hidden;text-align:center;justify-content:center;}div#n2-ss-13 .n2-ss-control-bullet-horizontal.n2-ss-control-bullet-fullsize{width:100%;}div#n2-ss-13 .n2-ss-control-bullet-vertical.n2-ss-control-bullet-fullsize{height:100%;flex-flow:column;}div#n2-ss-13 .nextend-bullet-bar{display:inline-flex;visibility:visible;align-items:center;flex-wrap:wrap;}div#n2-ss-13 .n2-bar-justify-content-left{justify-content:flex-start;}div#n2-ss-13 .n2-bar-justify-content-center{justify-content:center;}div#n2-ss-13 .n2-bar-justify-content-right{justify-content:flex-end;}div#n2-ss-13 .n2-ss-control-bullet-vertical > .nextend-bullet-bar{flex-flow:column;}div#n2-ss-13 .n2-ss-control-bullet-fullsize > .nextend-bullet-bar{display:flex;}div#n2-ss-13 .n2-ss-control-bullet-horizontal.n2-ss-control-bullet-fullsize > .nextend-bullet-bar{flex:1 1 auto;}div#n2-ss-13 .n2-ss-control-bullet-vertical.n2-ss-control-bullet-fullsize > .nextend-bullet-bar{height:100%;}div#n2-ss-13 .nextend-bullet-bar .n2-bullet{cursor:pointer;transition:background-color 0.4s;}div#n2-ss-13 .nextend-bullet-bar .n2-bullet.n2-active{cursor:default;}div#n2-ss-13 div.n2-ss-bullet-thumbnail-container{position:absolute;opacity:0;z-index:10000000;}div#n2-ss-13 .n2-ss-bullet-thumbnail-container .n2-ss-bullet-thumbnail{background-size:cover;background-repeat:no-repeat;background-position:center;}div#n2-ss-13 .n2-font-8ee5f12fccfb8b71c7c94c3cd63a48d7-hover{font-family: 'Rubik','sans-serif';color: #043178;font-size:175%;text-shadow: none;line-height: 1.5;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 600;}div#n2-ss-13 .n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph{font-family: 'Roboto','sans-serif';color: #282828;font-size:68.75%;text-shadow: none;line-height: 1.4;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 400;}div#n2-ss-13 .n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph a, div#n2-ss-13 .n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph a:FOCUS{font-family: 'Roboto','sans-serif';color: #1890d7;font-size:100%;text-shadow: none;line-height: 1.4;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 400;}div#n2-ss-13 .n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph a:HOVER, div#n2-ss-13 .n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph a:ACTIVE{font-family: 'Roboto','sans-serif';color: #1890d7;font-size:100%;text-shadow: none;line-height: 1.4;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 400;}div#n2-ss-13 .n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph{font-family: 'Roboto','sans-serif';color: #282828;font-size:87.5%;text-shadow: none;line-height: 1.4;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 400;}div#n2-ss-13 .n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph a, div#n2-ss-13 .n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph a:FOCUS{font-family: 'Roboto','sans-serif';color: #1890d7;font-size:100%;text-shadow: none;line-height: 1.4;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 400;}div#n2-ss-13 .n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph a:HOVER, div#n2-ss-13 .n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph a:ACTIVE{font-family: 'Roboto','sans-serif';color: #1890d7;font-size:100%;text-shadow: none;line-height: 1.4;font-weight: normal;font-style: normal;text-decoration: none;text-align: center;letter-spacing: normal;word-spacing: normal;text-transform: none;font-weight: 400;}div#n2-ss-13 .n2-style-2a0a200d6a6e1fade27fb9c90af83812-dot{background: #000000;background: RGBA(0,0,0,0.67);opacity:1;padding:5px 5px 5px 5px ;box-shadow: none;border-width: 0px;border-style: solid;border-color: #000000; border-color: RGBA(0,0,0,1);border-radius:50px;margin: 4px;}div#n2-ss-13 .n2-style-2a0a200d6a6e1fade27fb9c90af83812-dot.n2-active, div#n2-ss-13 .n2-style-2a0a200d6a6e1fade27fb9c90af83812-dot:HOVER, div#n2-ss-13 .n2-style-2a0a200d6a6e1fade27fb9c90af83812-dot:FOCUS{background: #053d8e;}</style><div id="n2-ss-13-align" class="n2-ss-align"><div class="n2-padding"><div id="n2-ss-13" data-creator="Smart Slider 3" class="n2-ss-slider n2-ow n2-has-hover n2notransition  n2-ss-load-fade " data-minFontSizedesktopPortrait="1" data-minFontSizedesktopLandscape="1" data-minFontSizetabletPortrait="1" data-minFontSizetabletLandscape="1" data-minFontSizemobilePortrait="1" data-minFontSizemobileLandscape="1" style="font-size: 1rem;" data-fontsize="16">        <div class="n2-ss-slider-1 n2-ss-swipe-element n2-ow">
<div class="n2-ss-slider-2 n2-ow" style="">
<div class="n2-ss-slider-3 n2-ow">
<div class="n2-ss-slider-pane n2-ow">
<div class="n2-ss-slide-group n2-ow "><div data-first="1" data-slide-duration="0" data-id="28" data-title="Libre costo" style="" class=" n2-ss-slide  n2-ss-slide-28 n2-ss-canvas n2-ow"><div class="n2-ss-slide-background n2-ow" data-mode="fill"><div class="n2-ss-slide-background-color" style="background-color: #f4f4f4;"></div></div><div class="n2-ss-layers-container n2-ow" data-csstextalign="center" style=""><div class="n2-ss-layer n2-ow" style="left:0px;top:-39px;width:auto;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="-39" data-responsivesize="1" data-desktopportraitwidth="auto" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="middle" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div id="n2-ss-13item1" class="n2-font-8ee5f12fccfb8b71c7c94c3cd63a48d7-hover   n2-ss-item-content n2-ow" style="display:block;">Libre de costo</div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:-112px;width:59px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="-112" data-responsivesize="1" data-desktopportraitwidth="59" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="middle" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class=" n2-ss-img-wrapper n2-ss-item-content n2-ow" style="overflow:hidden;"><img src="<?=_sliderimages_?>p_librecosto.png" id="n2-ss-13item2" alt="" style="display: inline-block; max-width: 100%; width: 100%;height: auto;" class=" n2-ow" data-no-lazy="1" data-hack="data-lazy-src" /></div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:253px;width:301px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="253" data-responsivesize="1" data-desktopportraitwidth="301" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="top" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class="n2-ss-item-content n2-ow"><div class="n2-ss-mobile n2-ow n2-ow-all"><p class="n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph   n2-ow">Aplica para todas las cuentas de ahorro, crédito e inversión para Personas Naturales o Jurídicas. En todas las operaciones se realizará un seguimiento de origen de los fondos.</p>
</div><div class="n2-ss-tablet n2-ow n2-ow-all"><p class="n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph   n2-ow">Aplica para todas las cuentas de ahorro, crédito e inversión para Personas Naturales o Jurídicas. En todas las operaciones se realizará un seguimiento de origen de los fondos.</p>
</div><div class="n2-ow n2-ow-all n2-ss-desktop"><p class="n2-font-01d567c5e6c1903221b2a7b424776d84-paragraph   n2-ow">Aplica para todas las cuentas de ahorro, crédito e inversión para Personas Naturales o Jurídicas. En todas las operaciones se realizará un seguimiento de origen de los fondos.</p>
</div></div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:175px;width:301px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="175" data-responsivesize="1" data-desktopportraitwidth="301" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="top" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class="n2-ss-item-content n2-ow"><div class="n2-ss-mobile n2-ow n2-ow-all"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">Realiza todas tus operaciones <b>SIN COSTO</b> en nuestro Sistema Integrado de Servicios (SIS Binarial) las 24 horas del día.</p>
</div><div class="n2-ss-tablet n2-ow n2-ow-all"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">Realiza todas tus operaciones <b>SIN COSTO</b> en nuestro Sistema Integrado de Servicios (SIS Binarial) las 24 horas del día.</p>
</div><div class="n2-ow n2-ow-all n2-ss-desktop"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">Realiza todas tus operaciones <b>SIN COSTO</b> en nuestro Sistema Integrado de Servicios (SIS Binarial) las 24 horas del día.</p>
</div></div></div></div></div></div><div class="n2-ss-slide-group n2-ow "><div data-slide-duration="0" data-id="29" data-title="Más rentabilidad" style="" class=" n2-ss-slide  n2-ss-slide-29 n2-ss-canvas n2-ow"><div class="n2-ss-slide-background n2-ow" data-mode="fill"><div class="n2-ss-slide-background-color" style="background-color: #f4f4f4;"></div></div><div class="n2-ss-layers-container n2-ow" data-csstextalign="center" style=""><div class="n2-ss-layer n2-ow" style="left:0px;top:-39px;width:auto;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="-39" data-responsivesize="1" data-desktopportraitwidth="auto" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="middle" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div id="n2-ss-13item5" class="n2-font-8ee5f12fccfb8b71c7c94c3cd63a48d7-hover   n2-ss-item-content n2-ow" style="display:block;">Más rentabilidad</div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:-112px;width:71px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="-112" data-responsivesize="1" data-desktopportraitwidth="71" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="middle" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class=" n2-ss-img-wrapper n2-ss-item-content n2-ow" style="overflow:hidden;"><img src="<?=_sliderimages_?>p_rentabilidad.png" id="n2-ss-13item6" alt="" style="display: inline-block; max-width: 100%; width: 100%;height: auto;" class=" n2-ow" data-no-lazy="1" data-hack="data-lazy-src" /></div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:175px;width:301px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="175" data-responsivesize="1" data-desktopportraitwidth="301" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="top" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class="n2-ss-item-content n2-ow"><div class="n2-ss-mobile n2-ow n2-ow-all"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">La cuenta de Ahorro a Plazo Fijo genera más interés para que tu dinero crezca durante un plazo determinado. Además, según el contrato pactado, puedes retirar tus intereses.</p>
</div><div class="n2-ss-tablet n2-ow n2-ow-all"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">La cuenta de Ahorro a Plazo Fijo genera más interés para que tu dinero crezca durante un plazo determinado. Además, según el contrato pactado, puedes retirar tus intereses.</p>
</div><div class="n2-ow n2-ow-all n2-ss-desktop"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">La cuenta de Ahorro a Plazo Fijo genera más interés para que tu dinero crezca durante un plazo determinado. Además, según el contrato pactado, puedes retirar tus intereses.</p>
</div></div></div></div></div></div><div class="n2-ss-slide-group n2-ow "><div data-slide-duration="0" data-id="30" data-title="Tú Eliges" style="" class=" n2-ss-slide  n2-ss-slide-30 n2-ss-canvas n2-ow"><div class="n2-ss-slide-background n2-ow" data-mode="fill"><div class="n2-ss-slide-background-color" style="background-color: #f4f4f4;"></div></div><div class="n2-ss-layers-container n2-ow" data-csstextalign="center" style=""><div class="n2-ss-layer n2-ow" style="left:0px;top:-39px;width:auto;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="-39" data-responsivesize="1" data-desktopportraitwidth="auto" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="middle" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div id="n2-ss-13item8" class="n2-font-8ee5f12fccfb8b71c7c94c3cd63a48d7-hover   n2-ss-item-content n2-ow" style="display:block;">Tú eliges</div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:-112px;width:61px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="-112" data-responsivesize="1" data-desktopportraitwidth="61" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="middle" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class=" n2-ss-img-wrapper n2-ss-item-content n2-ow" style="overflow:hidden;"><img src="<?=_sliderimages_?>p_tueliges.png" id="n2-ss-13item9" alt="" style="display: inline-block; max-width: 100%; width: 100%;height: auto;" class=" n2-ow" data-no-lazy="1" data-hack="data-lazy-src" /></div></div><div class="n2-ss-layer n2-ow" style="left:0px;top:175px;width:338px;height:auto;overflow:visible;" data-pm="absolute" data-responsiveposition="1" data-desktopportraitleft="0" data-desktopportraittop="175" data-responsivesize="1" data-desktopportraitwidth="338" data-desktopportraitheight="auto" data-desktopportraitalign="center" data-desktopportraitvalign="top" data-parentid="" data-desktopportraitparentalign="center" data-desktopportraitparentvalign="middle" data-sstype="layer" data-rotation="0" data-desktopportrait="1" data-desktoplandscape="1" data-tabletportrait="1" data-tabletlandscape="1" data-mobileportrait="1" data-mobilelandscape="1" data-adaptivefont="0" data-desktopportraitfontsize="100" data-plugin="rendered"><div class="n2-ss-item-content n2-ow"><div class="n2-ss-mobile n2-ow n2-ow-all"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">Tienes la opción de elegir la moneda en la que quieres ahorrar: Soles o Dólares</p>
</div><div class="n2-ss-tablet n2-ow n2-ow-all"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">Tienes la opción de elegir la moneda en la que quieres ahorrar: Soles o Dólares</p>
</div><div class="n2-ow n2-ow-all n2-ss-desktop"><p class="n2-font-90d62ccf63464a1126ccb5749ed16ea1-paragraph   n2-ow">Tienes la opción de elegir la moneda en la que quieres ahorrar: Soles o Dólares</p>
</div></div></div></div></div></div></div></div></div></div>
<div data-position="below" data-offset="10" class="n2-ss-widget n2-ss-widget-display-desktop n2-ss-widget-display-tablet n2-ss-widget-display-mobile  n2-flex n2-ss-control-bullet n2-ss-control-bullet-horizontal" style="margin-top:10px;"><div class=" nextend-bullet-bar n2-ow n2-bar-justify-content-center"></div></div>
</div><div class="n2-clear"></div><div id="n2-ss-13-spinner" style="display: none;"><div><div class="n2-ss-spinner-simple-white-container"><div class="n2-ss-spinner-simple-white"></div></div></div></div></div></div><div id="n2-ss-13-placeholder" style="position: relative;z-index:2;background-color:RGBA(0,0,0,0);max-height:370px; background-color:RGBA(255,255,255,0);"><img style="width: 100%; max-width:1250px; display: block;opacity:0;margin:0px;" class="n2-ow" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZlcnNpb249IjEuMCIgd2lkdGg9IjEyNTAiIGhlaWdodD0iMzcwIiA+PC9zdmc+" alt="Slider" /></div></div>


		</div>

	</div>
</section>


<section id="cuerpo_bpi" class="background_amarillo2" data-aos="fade-down">
	<div id="bpi-wrap">
		
		<div class="ahorro_operaciones">
			<div class="ahorro_operaciones_image">
				<img src="<?=_images_?>mujer_operaciones.png" />
			</div>

			<div class="ahorro_operaciones_info">
				<h1 class="azul1">¿Qué operaciones puedo realizar?</h1>
				<ul class="check">
					<li>Transferencias a otros bancos previa solicitud.</li>
					<li>Solicitud de retiros y aumentos de efectivo mediante nuestro SIS Binarial.</li>
					<li>Consultas de saldos y movimientos a través de nuestro SIS Binarial.</li>
				</ul>

				<h1 class="azul1">Especificaciones</h1>
				<ul class="check">
					<li>Monto de apertura: S/ 5,000.00 o US$ 1,500.00.</li>
					<li>No cobra mantenimiento de cuenta.</li>
				</ul>
			</div>

			<div class="ahorro_operaciones_image_m">
				<img src="<?=_images_?>mujer_operaciones_m.png" />
			</div>
		</div>

	</div>
</section>


<section id="cuerpo_bpi" data-aos="fade-down">
	<div id="bpi-wrap">
		
		<div class="ahorro_aperturar">
			<h1 class="azul1">¿Cómo aperturar una cuenta de ahorro a plazo fijo?</h1>
			
			<h2 class="gris2">Presencial</h2>
			<p>Acercarse a oficinas presentando su DNI y copia del último recibo de pago de luz y agua.</p>

			<h2 class="gris2">No presencial</h2>
			<ol>
				<li>Comunicarse con uno de nuestros asesores.</li>
				<li>Enviar los documentos solicitados por correo electrónico.</li>
				<li>Realizar el depósito del monto determinado a las cuentas corrientes de la empresa.</li>
			</ol>

			<h2 class="gris2">SIS Binarial</h2>
			<p><a href="<?=_base_?>intranet/">Regístrate aquí</a> y abre tu primera cuenta MegaTasa con nosotros desde 5,000 soles sin costos de mantenimiento.</p>

			<h2 class="gris2">Oficinas BPI</h2>
			<p>
				Av. Javier Prado 476 Piso 21 cruce con Orquídeas 444 - San Isidro.<br/>
				Horario: de Lunes a Viernes de 9:00 a.m hasta las 6:00 pm.
			</p>
		</div>

		<div class="ahorro_aperturar_documentacion background_gris1">
			<h2 class="gris2" style="margin:0; padding:0;">Documentación</h2>
			<h2 class="gris2" style="font-weight:600; margin:0; padding:0; padding-bottom:25px;">Cuenta MegaTasa</h2>

			<a href="#">Modelo de Contrato</a>
			<a href="#">Cartilla de Información</a>
			<a href="#">Solicitud</a>
			<a href="#">Tarifario</a>
			<a href="#">Fórmulas y ejemplos</a>
			<a href="#">Beneficios, riesgos y condiciones</a>
		</div>

	</div>
</section>


<section id="cuerpo_bpi" class="background_gris1" data-aos="fade-down">
	<div id="bpi-wrap">
		<div class="ahorro_preguntas">
			<h1 class="azul1">Preguntas frecuentes</h1>




<div id="accordion">
    <button data-toggle="collapse" data-target="#collapse1" aria-expanded="true" aria-controls="collapse1">
	  	<h2>¿Qué es UNA Cuenta de Ahorro a Plazo Fijo?</h2>
    </button>
	<div id="collapse1" class="collapse show" aria-labelledby="heading1" data-parent="#accordion">
		<div class="card-body">
	    	Es una cuenta con la que obtienes una mejor rentabilidad al mantener tu dinero depositado por un período determinado.
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse2" aria-expanded="true" aria-controls="collapse2">
	  	<h2>¿Qué conceptos se cobran en la cuenta?</h2>
    </button>
	<div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordion">
		<div class="card-body">
	    Solo se cobra los envíos de Estados de Cuenta.
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse3" aria-expanded="true" aria-controls="collapse3">
	  	<h2>¿Puedo retirar mis intereses antes del vencimiento del plazo?</h2>
    </button>
	<div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordion">
		<div class="card-body">
	    Sí, puedes retirar los intereses que diariamente vaya acumulando tu cuenta dependiendo de las especificaciones del contrato.
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse4" aria-expanded="true" aria-controls="collapse4">
	  	<h2>¿Puedo cancelar mi cuenta antes del vencimiento del plazo?</h2>
    </button>
	<div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordion">
		<div class="card-body">
	    Sí, puedes retirar cuando quieras y al instante antes de su vencimiento, y te devolvemos tu capital más intereses calculados con la menor tasa de interés según tarifario de retiros anticipados.
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse5" aria-expanded="true" aria-controls="collapse5">
	  	<h2>¿Qué sucede con mi cuenta de Ahorro a Plazo Fijo cuando llega la fecha de vencimiento?</h2>
    </button>
	<div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#accordion">
		<div class="card-body">
	    Se renueva automáticamente a la tasa vigente establecida en el tarifario.
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse6" aria-expanded="true" aria-controls="collapse6">
	  	<h2>¿Qué es la TREA?</h2>
    </button>
	<div id="collapse6" class="collapse" aria-labelledby="heading6" data-parent="#accordion">
		<div class="card-body">
	    La TREA es la Tasa de Rendimiento Efectiva Anual y te permite saber cuánto ganarás efectivamente por el dinero que deposites al vencimiento del plazo, considerando todos los cargos por comisiones y gastos, bajo el supuesto de cumplimiento de todas las condiciones pactadas.
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse7" aria-expanded="true" aria-controls="collapse7">
	  	<h2>¿Cuál es el procedimiento de cancelación de la cuenta?</h2>
    </button>
	<div id="collapse7" class="collapse" aria-labelledby="heading7" data-parent="#accordion">
		<div class="card-body">
	    El cliente deberá acercarse a nuestras oficinas con su DNI y solicitar la cancelación de la cuenta, indicando lo siguiente:<br><br>
		1. Nombre del cliente.<br>
		2. Tipo y número de documento de identidad.<br>
		3. Moneda y número de cuenta.<br>
		4. Motivo de cierre de la cuenta.<br>
		5. Si hay saldo a favor: Indique la forma de pago al cliente.<br>
		6. Si hay saldo deudor: Indique la forma de cobro al cliente.<br>
		7. Nombre de la persona autorizada por el cliente a realizar la operación.<br>
		8. Firma(s) del titular(es).<br>
		</div>
	</div>

	<button data-toggle="collapse" data-target="#collapse8" aria-expanded="true" aria-controls="collapse8">
	  	<h2>¿A qué instancias puedo recurrir para presentar un reclamo?</h2>
    </button>
	<div id="collapse8" class="collapse" aria-labelledby="heading8" data-parent="#accordion">
		<div class="card-body">
	    BPI ha implementado un Libro de Reclamaciones virtual (Especificar en qué sección se encuentra). Asimismo, puedes dirigirte a la Plataforma de Atención al Usuario de la SBS o de Indecopi en: (<a href="https://www.sbs.gob.pe" target="_blank">www.sbs.gob.pe</a>).<br/>
	    Ver el <a href="https://interbank.pe/documents/20182/343622/glosario_de_terminos_actual.pdf/acca1699-9d9e-448c-8ddd-4c802dddc6f1" target="_blank">Glosario de Términos</a>.
		</div>
	</div>




</div>





		</div>
	</div>
</section>

<?php include(_includes_."inc.footer.php"); ?>